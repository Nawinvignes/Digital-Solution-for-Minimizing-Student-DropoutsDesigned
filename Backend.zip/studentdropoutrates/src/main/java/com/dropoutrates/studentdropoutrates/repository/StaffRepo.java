package com.dropoutrates.studentdropoutrates.repository;

import org.springframework.data.jpa.repository.JpaRepository;

// import com.dropoutrates.studentdropoutrates.model.Parent;
import com.dropoutrates.studentdropoutrates.model.Staff;

public interface StaffRepo extends JpaRepository<Staff,Integer>{

    Staff findByName(String a);
}
