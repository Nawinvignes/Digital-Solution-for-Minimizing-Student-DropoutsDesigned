package com.dropoutrates.studentdropoutrates.model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonManagedReference;

// import jakarta.annotation.Generated;
import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Setter
@Getter
@NoArgsConstructor
@AllArgsConstructor
public class Staff {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int staffid;
    private String name;
    private String phone;
    private String email;
    private String role;
    private String department;

    @OneToMany(mappedBy = "staff")
    private List<Student> students;

    @OneToMany(mappedBy = "staff")
    private List<Parent> parents;
}