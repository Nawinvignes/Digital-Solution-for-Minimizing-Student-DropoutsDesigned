package com.dropoutrates.studentdropoutrates.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

// import com.dropoutrates.studentdropoutrates.model.Parent;
import com.dropoutrates.studentdropoutrates.model.Staff;
import com.dropoutrates.studentdropoutrates.repository.StaffRepo;

@Service
public class StaffService {
    @Autowired
    public StaffRepo staffRepo;

    public Staff savStaff(Staff staff)
    {
        return staffRepo.save(staff);
    }

    public List<Staff> gPStaffs()
    {
       return staffRepo.findAll();
    }

    public Staff findStaffid(int id)
    {
        return staffRepo.findById(id).orElse(null);
    }

    public Staff findStaffName(String a)
    {
        return staffRepo.findByName(a);
    }

    public void deleteStaff(int id)
    {
        staffRepo.deleteById(id);
    }
}

