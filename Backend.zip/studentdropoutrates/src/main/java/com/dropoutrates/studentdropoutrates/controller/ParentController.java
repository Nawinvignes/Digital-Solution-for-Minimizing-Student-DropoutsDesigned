package com.dropoutrates.studentdropoutrates.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.dropoutrates.studentdropoutrates.model.Parent;
import com.dropoutrates.studentdropoutrates.service.ParentService;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
// import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.PutMapping;



@RestController
@RequestMapping("/parent")
public class ParentController {
    @Autowired
    public ParentService parentService;

    @PostMapping("/user")
    public ResponseEntity<Parent> saveParent(@RequestBody Parent parent) {
        Parent p = parentService.savParent(parent);
        if(p!=null)
        {
            return ResponseEntity.ok(p);
        }
        return ResponseEntity.status(401).build();
    }

    @GetMapping("/user")
    public ResponseEntity<List<Parent>> gParents() {
        List<Parent> p = parentService.gParents();
        if(p!=null)
        {
            return ResponseEntity.ok(p);
        }
        return ResponseEntity.status(404).build();
    }

    @GetMapping("/user/{id}")
    public ResponseEntity<Parent> getParentbyid(@PathVariable("id") int id) {
        Parent p = parentService.findParentid(id);
        if(p!=null)
        {
             return ResponseEntity.ok(p);
        }
        return ResponseEntity.status(404).build();
    }

    @GetMapping("/user/{name}")
    public ResponseEntity<Parent> getParentbyid(@PathVariable("name") String name) {
        Parent p = parentService.findParentName(name);
        if(p!=null)
        {
             return ResponseEntity.ok(p);
        }
        return ResponseEntity.status(404).build();
    }

    @PutMapping("user/{id}")
    public ResponseEntity<Parent> updateParent(@PathVariable("id") int id, @RequestBody Parent updateparent) {
        
        Parent p = parentService.findParentid(id);
        if(p!=null)
        {
            p.setName(updateparent.getName());
            p.setAddress(updateparent.getAddress());
            p.setEmail(updateparent.getEmail());
            p.setOccupation(updateparent.getOccupation());
            p.setPhone(updateparent.getPhone());
            p.setRelation(updateparent.getRelation());
            p.setStudent(updateparent.getStudent());
            p.setStaff(updateparent.getStaff());
            Parent p1 = parentService.savParent(p);
            return ResponseEntity.ok(p1);
        }
        return ResponseEntity.status(404).build();
        
    }
    
    @DeleteMapping("user/{id}")
    public ResponseEntity<String> deletParent(@PathVariable("id") int id){
        Parent p = parentService.findParentid(id);
        if(p!=null)
        {
            parentService.deleteParent(id);
            return ResponseEntity.ok("Parent User deleted");
        }
        return ResponseEntity.status(409).build();
    }
    
    
    
}