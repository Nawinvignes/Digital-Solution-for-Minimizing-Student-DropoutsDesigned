package com.dropoutrates.studentdropoutrates.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

// import com.dropoutrates.studentdropoutrates.model.Parent;
import com.dropoutrates.studentdropoutrates.model.Student;
import com.dropoutrates.studentdropoutrates.service.StudentService;

@RestController
@RequestMapping("/student")
public class StudentController {
    @Autowired
    public StudentService studentService;

    @PostMapping("/user")
    public ResponseEntity<Student> saveParent(@RequestBody Student student) {
        Student p = studentService.savStudent(student);
        if(p!=null)
        {
            return ResponseEntity.ok(p);
        }
        return ResponseEntity.status(401).build();
    }

    @GetMapping("/user")
    public ResponseEntity<List<Student>> gParents() {
        List<Student> p = studentService.gStudents();
        if(p!=null)
        {
            return ResponseEntity.ok(p);
        }
        return ResponseEntity.status(404).build();
    }

    @GetMapping("/user/{id}")
    public ResponseEntity<Student> getParentbyid(@PathVariable("id") int id) {
        Student p = studentService.findStudentid(id);
        if(p!=null)
        {
             return ResponseEntity.ok(p);
        }
        return ResponseEntity.status(404).build();
    }

    @GetMapping("/user/{name}")
    public ResponseEntity<Student> getParentbyid(@PathVariable("name") String name) {
        Student p= studentService.findStudentName(name);
        if(p!=null)
        {
             return ResponseEntity.ok(p);
        }
        return ResponseEntity.status(404).build();
    }

    // @PutMapping("user/{id}")
    // public ResponseEntity<Student> updateParent(@PathVariable("id") int id, @RequestBody Parent updateparent) {
        
    //     Parent p = parentService.findParentid(id);
    //     if(p!=null)
    //     {
    //         p.setName(updateparent.getName());
    //         p.setAddress(updateparent.getAddress());
    //         p.setEmail(updateparent.getEmail());
    //         p.setOccupation(updateparent.getOccupation());
    //         p.setPhone(updateparent.getPhone());
    //         p.setRelation(updateparent.getRelation());
    //         p.setStudent(updateparent.getStudent());
    //         p.setStaff(updateparent.getStaff());
    //         Parent p1 = parentService.savParent(p);
    //         return ResponseEntity.ok(p1);
    //     }
    //     return ResponseEntity.status(404).build();
        
    // }
    
    @DeleteMapping("user/{id}")
    public ResponseEntity<String> deletParent(@PathVariable("id") int id){
        Student p = studentService.findStudentid(id);
        if(p!=null)
        {
            studentService.deleteStudent(id);
            return ResponseEntity.ok("Student User deleted");
        }
        return ResponseEntity.status(409).build();
    }
    
}
