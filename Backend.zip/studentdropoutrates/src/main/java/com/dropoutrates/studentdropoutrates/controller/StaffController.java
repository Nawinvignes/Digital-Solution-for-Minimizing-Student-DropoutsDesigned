package com.dropoutrates.studentdropoutrates.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

// import com.dropoutrates.studentdropoutrates.model.Parent;
import com.dropoutrates.studentdropoutrates.model.Staff;
import com.dropoutrates.studentdropoutrates.service.StaffService;

@RestController
@RequestMapping("/staff")
public class StaffController {
    @Autowired
    public StaffService staffService;
    
    @PostMapping("/user")
    public ResponseEntity<Staff> saveParent(@RequestBody Staff staff) {
        Staff s = staffService.savStaff(staff);
        if(s!=null)
        {
            return ResponseEntity.ok(s);
        }
        return ResponseEntity.status(401).build();
    }

    @GetMapping("/user")
    public ResponseEntity<List<Staff>> gParents() {
        List<Staff> p = staffService.gPStaffs();
        if(p!=null)
        {
            return ResponseEntity.ok(p);
        }
        return ResponseEntity.status(404).build();
    }

    @GetMapping("/user/{id}")
    public ResponseEntity<Staff> getParentbyid(@PathVariable("id") int id) {
        Staff p = staffService.findStaffid(id);
        if(p!=null)
        {
             return ResponseEntity.ok(p);
        }
        return ResponseEntity.status(404).build();
    }

    @GetMapping("/user/{name}")
    public ResponseEntity<Staff> getParentbyid(@PathVariable("name") String name) {
        Staff p = staffService.findStaffName(name);
        if(p!=null)
        {
             return ResponseEntity.ok(p);
        }
        return ResponseEntity.status(404).build();
    }

    // @PutMapping("user/{id}")
    // public ResponseEntity<Staff> updateParent(@PathVariable("id") int id, @RequestBody Parent updateparent) {
        
    //     Parent p = parentService.findParentid(id);
    //     if(p!=null)
    //     {
    //         p.setName(updateparent.getName());
    //         p.setAddress(updateparent.getAddress());
    //         p.setEmail(updateparent.getEmail());
    //         p.setOccupation(updateparent.getOccupation());
    //         p.setPhone(updateparent.getPhone());
    //         p.setRelation(updateparent.getRelation());
    //         p.setStudent(updateparent.getStudent());
    //         p.setStaff(updateparent.getStaff());
    //         Parent p1 = parentService.savParent(p);
    //         return ResponseEntity.ok(p1);
    //     }
    //     return ResponseEntity.status(404).build();
        
    // }
    
    @DeleteMapping("user/{id}")
    public ResponseEntity<String> deletParent(@PathVariable("id") int id){
        Staff p = staffService.findStaffid(id);
        if(p!=null)
        {
            staffService.deleteStaff(id);
            return ResponseEntity.ok("Staff user Deleted");
        }
        return ResponseEntity.status(409).build();
    }
}