package com.dropoutrates.studentdropoutrates.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

// import com.dropoutrates.studentdropoutrates.model.Parent;
import com.dropoutrates.studentdropoutrates.model.Student;
import com.dropoutrates.studentdropoutrates.repository.StudentRepo;

@Service
public class StudentService {
    
    @Autowired
    public StudentRepo studentRepo;

    public Student savStudent(Student student)
    {
        return studentRepo.save(student);
    }

    public List<Student> gStudents()
    {
       return studentRepo.findAll();
    }

    public Student findStudentid(int id)
    {
        return studentRepo.findById(id).orElse(null);
    }

    public Student findStudentName(String a)
    {
        return studentRepo.findByName(a);
    }

    public void deleteStudent(int id)
    {
        studentRepo.deleteById(id);
    }
}
