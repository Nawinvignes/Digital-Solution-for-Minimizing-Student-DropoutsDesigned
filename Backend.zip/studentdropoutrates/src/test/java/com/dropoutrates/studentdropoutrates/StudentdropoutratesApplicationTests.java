package com.dropoutrates.studentdropoutrates;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StudentdropoutratesApplicationTests {

	@Test
	void contextLoads() {
	}

}
