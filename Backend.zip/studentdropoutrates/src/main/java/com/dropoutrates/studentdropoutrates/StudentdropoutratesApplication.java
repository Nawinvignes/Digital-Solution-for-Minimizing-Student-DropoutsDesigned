package com.dropoutrates.studentdropoutrates;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StudentdropoutratesApplication {

	public static void main(String[] args) {
		SpringApplication.run(StudentdropoutratesApplication.class, args);
	}

}
