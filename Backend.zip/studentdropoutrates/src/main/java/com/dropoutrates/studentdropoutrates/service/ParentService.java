package com.dropoutrates.studentdropoutrates.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dropoutrates.studentdropoutrates.model.Parent;
import com.dropoutrates.studentdropoutrates.repository.ParentRepo;

@Service
public class ParentService {

    @Autowired
    public ParentRepo parentRepo;

    public Parent savParent(Parent parent)
    {
        return parentRepo.save(parent);
    }

    public List<Parent> gParents()
    {
       return parentRepo.findAll();
    }

    public Parent findParentid(int id)
    {
        return parentRepo.findById(id).orElse(null);
    }

    public Parent findParentName(String a)
    {
        return parentRepo.findByName(a);
    }

    public void deleteParent(int id)
    {
        parentRepo.deleteById(id);
    }
}
