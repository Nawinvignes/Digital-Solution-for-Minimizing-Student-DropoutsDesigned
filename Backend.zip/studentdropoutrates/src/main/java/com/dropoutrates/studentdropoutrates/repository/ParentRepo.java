package com.dropoutrates.studentdropoutrates.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.dropoutrates.studentdropoutrates.model.Parent;

public interface ParentRepo extends JpaRepository<Parent,Integer>{
    Parent findByName(String a);
}
