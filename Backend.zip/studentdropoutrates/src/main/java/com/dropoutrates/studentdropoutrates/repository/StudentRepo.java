package com.dropoutrates.studentdropoutrates.repository;

import org.springframework.data.jpa.repository.JpaRepository;

// import com.dropoutrates.studentdropoutrates.model.Parent;
import com.dropoutrates.studentdropoutrates.model.Student;

public interface StudentRepo extends JpaRepository<Student,Integer>{

    Student findByName(String a);
}
